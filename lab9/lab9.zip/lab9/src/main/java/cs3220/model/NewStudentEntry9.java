package cs3220.model;

public class NewStudentEntry9 {
	private String name;
	private int birthYear;
	private String parentName;
	private String parentEmail;
	private NewGroupEntry9 group;
	
	// constructor
	public NewStudentEntry9(String name, int birthYear, String parentName, String parentEmail, NewGroupEntry9 group){
		this.name = name;
		this.birthYear = birthYear;
		this.parentName = parentName;
		this.parentEmail = parentEmail;
		this.group = group;
	}	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBirthYear() {
		return birthYear;
	}
	public void setBirthYear(int birthYear) {
		this.birthYear = birthYear;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getParentEmail() {
		return parentEmail;
	}
	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}

	public NewGroupEntry9 getGroup() {
		return group;
	}

	public void setGroup(NewGroupEntry9 group) {
		this.group = group;
	}
}
